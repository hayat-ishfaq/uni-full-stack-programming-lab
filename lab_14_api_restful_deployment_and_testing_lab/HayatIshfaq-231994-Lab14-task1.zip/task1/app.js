const express = require('express');
const dotenv = require('dotenv');

dotenv.config();

const weatherRoutes = require('./routes/WeatherRoutes');

const app = express();

app.use(express.json());

// Register the weather routes under the API prefix.
app.use('/api/weather', weatherRoutes);

module.exports = app;
