const dotenv = require('dotenv');
const app = require('./app');

dotenv.config();

const PORT = process.env.PORT || 5000;

if (require.main === module) {
	app.listen(PORT, () => {
		console.log(`Weather API server is running on port ${PORT}`);
	});
}

module.exports = app;
